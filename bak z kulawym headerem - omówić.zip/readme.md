datamasters company page

contains:

-a few sections coded based on Figma project

-Sass used for styling

-Responsive Web Design for each section

-burger menu with animated open/close icon

-some hover animations
